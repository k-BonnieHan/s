package com.sos.board;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sos.Common.Pagination;

@Controller
public class BoardController {

	@Autowired
	private BoardServiceImpl boardService;

	@RequestMapping(value = "/board/getBoardList", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public ModelAndView boardList(HttpServletRequest request, @RequestParam(required = false, defaultValue = "1") int pageNo
			, @RequestParam(required = false, defaultValue = "10") int pageSize) {
		ModelAndView mav = new ModelAndView();
		HashMap<Object, Object> reqMap = new HashMap<Object, Object>();
		reqMap.put("pageNo", pageNo);
		reqMap.put("pageSize", pageSize);
		
		List<HashMap<String,String>> boardList = new ArrayList<HashMap<String,String>>();
		boardList = boardService.boardList(reqMap);
		int boardSize = 0;
		
		if (boardList != null) {
			boardSize = Integer.parseInt((String.valueOf(boardList.get(0).get("totalCnt"))));
		}
		
		Pagination pagination = new Pagination(boardSize, pageNo);
		try {
			for (HashMap<String, String> hashMap : boardList) {
				System.out.println("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
				for(String key : hashMap.keySet()){
	               System.out.println("키 : " + key + " 값  : " + String.valueOf(hashMap.get(key)));
	            }
				System.out.println("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		mav.addObject("listCnt", boardSize);
	    mav.addObject("pagination", pagination);
		mav.addObject("boardList", boardList);
		
		mav.setViewName("/board/noticeBoard");

		return mav;
	}
}
