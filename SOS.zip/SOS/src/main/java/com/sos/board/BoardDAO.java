package com.sos.board;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.sos.Common.SqlManager;

@Component
public class BoardDAO {
	public static SqlSessionFactory sqlMapper = SqlManager.getInstance_SuremWholeDB();

	private static final String NS = BoardDAO.class.getPackage().getName() + ".";
	
	public List<HashMap<String, String>> boardList(HashMap<Object, Object> reqMap) {
		SqlSession session = sqlMapper.openSession();
		for(Object key : reqMap.keySet()){
            System.out.println("키 : " + key + " 값  : " + String.valueOf(reqMap.get(key)));
         }
		return session.selectList(NS+"listTemplate", reqMap);
	}

}
