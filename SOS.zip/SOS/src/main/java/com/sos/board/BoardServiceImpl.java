package com.sos.board;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private BoardDAO boardDAO;

	@Override
	public List<HashMap<String, String>> boardList(HashMap<Object, Object> reqMap) {
		return boardDAO.boardList(reqMap);
	}
}
