package com.sos.Common;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class SqlManager {
	public static SqlSessionFactory sqlMapper;
	
	public static SqlSessionFactory getInstance_SuremWholeDB(){
		try {
			Reader reader=Resources.getResourceAsReader("myBatis/SqlMapConfig.xml");
			sqlMapper = new SqlSessionFactoryBuilder().build(reader, "SuremWholeDB");
		} catch (IOException e) {
			System.out.println("SqlSessionFactory Reader Error:" + e);
			e.printStackTrace();
		}
		return sqlMapper;
	}
	
	public static SqlSessionFactory getInstance_SuremDB_17(){
		try {
			Reader reader=Resources.getResourceAsReader("myBatis/SqlMapConfig.xml");
			sqlMapper = new SqlSessionFactoryBuilder().build(reader, "SuremDB17");
		} catch (IOException e) {
			System.out.println("SqlSessionFactory Reader Error:" + e);
			e.printStackTrace();
		}
		return sqlMapper;
	}
}
