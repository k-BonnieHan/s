function goLogin() {
	
	$("#pass").value
	var newForm=document.createElement("form");
	newForm.setAttribute("method","POST");
	newForm.setAttribute("action","/login");
	document.body.appendChild(newForm);
	
	var tagID=document.createElement("input");
	tagID.setAttribute("type","hidden");
	tagID.setAttribute("name","id");
	tagID.setAttribute("value",$("#id").value);
	newForm.appendChild(tagID);
	
	var tagPASS=document.createElement("input");
	tagPASS.setAttribute("type","hidden");
	tagPASS.setAttribute("name","pass");
	tagPASS.setAttribute("value",$("#pass").value);
	newForm.appendChild(tagPASS);
	
	newForm.submit();
}
