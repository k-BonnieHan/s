function goPage(leftMenu, e) {
	$.ajax({
			type : "post",
			url : "/menu/"+leftMenu,
			async : false,
			data : {leftMenu : leftMenu},
			success : function(html){
				tbl = html;
			}, error : function(e){
				console.log(e);
			}
		});
		$('#templateMain-contents').html(tbl);
		$(".dropdown-content-inc .circle").css("display","none");
		$(e).closest(".dropdown-content-inc").find(".circle").css("display","block");
		
	/**
		 * 오피스 관리 -
		 * 사용자 관리 - userManager(사용자현황), userReigst(사용자등록)
		 * 모니터링 - 
		 * 입퇴실 관리 - checkInOutManager(입퇴실현황), reservation(예약현황), reservationCancellation(예약취소현황),useStatistics(이용통계)
		 * 게시판 - noticeBoard(공지사항), qnaBoard(질문답변)
		 * 수금관리 -
		 * */         
}
