package com.sos.admin;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DaoSupport;
import org.springframework.stereotype.Service;

@Service
public class loginServiceImpl implements loginService {
	
	@Autowired
	private loginDaoInter Dao;

	@Override
	public List<HashMap<String, String>> boardList(HashMap<Object, Object> reqMap) {
		return Dao.adminList(reqMap);
	}
}
