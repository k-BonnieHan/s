package com.sos.admin;

import java.util.HashMap;
import java.util.List;

public interface loginService {
	List<HashMap<String, String>> boardList(HashMap<Object, Object> reqMap);
}
