package com.sos.admin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

public interface loginDaoInter {

	//로그인
	List<HashMap<String, String>> adminList(HashMap<Object,Object> reqMap);	
	adminDto login(String ad_id);
	
	//로그아웃
	void logout(HttpSession session);

}
