package com.sos.admin;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PmMyPageController {

	//마이페이지 정보수정 info_edit
		@RequestMapping("info_edit")
		   public String info_edit() {
		      return "info_edit";
		   }
}