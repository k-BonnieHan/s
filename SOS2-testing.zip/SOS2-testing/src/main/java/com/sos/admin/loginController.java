package com.sos.admin;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sos.admin.*;

@Controller
public class loginController {
	@Autowired
	private loginDaoInter loginDao;
	
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public String submitLogin(HttpSession session, 
			@RequestParam("ad_id") String ad_id, @RequestParam("ad_pw") String ad_pw) {
		
		adminDto pdto = loginDao.login(ad_id);
		if(pdto != null) {
			String retPass = pdto.getAd_pw();
			System.out.println(retPass + " " + ad_pw);
			if(retPass.equals(ad_pw)) {
				session.setAttribute("ad_id", ad_id);
				session.setAttribute("ad_pw", ad_pw);
				System.out.println(ad_id + ad_pw);
				return "redirect:/login#sosManage";
			}else {
				return "login.jsp";
			}
		}
		return "";
	}

	
	// 로그아웃
		@RequestMapping("logout")
	    public ModelAndView logout(HttpSession session) {
			loginDao.logout(session);
			//session.invalidate();
			ModelAndView mv = new ModelAndView();
			mv.setViewName("loginform");
			return mv;
	    }


	
	
	

}
