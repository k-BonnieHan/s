package com.sos.admin;

public class adminDto {
	private String ad_id, ad_pw;

	public String getAd_id() {
		return ad_id;
	}

	public void setAd_id(String ad_id) {
		this.ad_id = ad_id;
	}

	public String getAd_pw() {
		return ad_pw;
	}

	public void setAd_pw(String ad_pw) {
		this.ad_pw = ad_pw;
	}
	
}
