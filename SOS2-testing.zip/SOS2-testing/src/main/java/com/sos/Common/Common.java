package com.sos.Common;

import java.util.HashMap;

public class Common {
	public static Object mapCheck(Object reqMapValue) {
		String convertValue = "";
		System.out.println("reqMapValue : " + reqMapValue);
		convertValue = String.valueOf(reqMapValue).toString();
		return convertValue;
	}
}
