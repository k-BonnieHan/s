package com.sos.main;

import java.text.DateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sos.board.BoardServiceImpl;
import com.sos.Common.*;

/**
 * Handles requests for the application home page.
 */
@Controller
public class MainController {
	
	@Autowired
	private BoardServiceImpl boardService;
	
	private static final Logger logger = LoggerFactory.getLogger(MainController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "/login";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("viewPage", "/WEB-INF/views/board/noticeBoard.jsp");
		mav.setViewName("template/templateMain");
		return mav;
	}
	
	@RequestMapping(value = "/menu/{menu}", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView menu(@PathVariable ("menu") String menu, @RequestParam(required = false, defaultValue = "1") int pageNo
			, @RequestParam(required = false, defaultValue = "10") int pageSize) {
		ModelAndView mav = new ModelAndView();
		
		/**
		 * 오피스 관리 -
		 * 사용자 관리 - userManager(사용자현황), userReigst(사용자등록)
		 * 모니터링 - 
		 * 입퇴실 관리 - checkInOutManager(입퇴실현황), reservation(예약현황), reservationCancellation(예약취소현황),useStatistics(이용통계)
		 * 게시판 - noticeBoard(공지사항), qnaBoard(질문답변)
		 * 수금관리 -
		 * */   
		try {
		mav.setViewName("/board/qnaBoard");
		String path = "";
		if(menu != null && !"".equals(menu)) {
			if("qnaBoard".equals(menu)) {
				mav.setViewName("/board/qnaBoard");
				
			}else if("noticeBoard".equals(menu)){
				HashMap<Object, Object> reqMap = new HashMap<Object, Object>();
				reqMap.put("pageNo", pageNo);
				reqMap.put("pageSize", pageSize);
				
				List<HashMap<String,String>> boardList = new ArrayList<HashMap<String,String>>();
				boardList = boardService.boardList(reqMap);
				int boardSize = 0;
				
				if (boardList != null) {
					boardSize = Integer.parseInt((String.valueOf(boardList.get(0).get("totalCnt"))));
				}
				
				Pagination pagination = new Pagination(boardSize, pageNo);
				
				try {
					for (HashMap<String, String> hashMap : boardList) {
						System.out.println("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
						for(String key : hashMap.keySet()){
			               System.out.println("키 : " + key + " 값  : " + String.valueOf(hashMap.get(key)));
			            }
						System.out.println("ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
				mav.addObject("listCnt", boardSize);
			    mav.addObject("pagination", pagination);
				mav.addObject("boardList", boardList);
				
				mav.setViewName("/board/noticeBoard");
			}else if("checkInOutManager".equals(menu)){
				mav.setViewName("/checkInOut/checkInOutManager");
				
			}else if("reservation".equals(menu)){
				mav.setViewName("/checkInOut/reservation");				
				
			}else if("reservationCancellation".equals(menu)){
				mav.setViewName("/checkInOut/reservationCancellation");			
				
			}else if("useStatistics".equals(menu)){
				mav.setViewName("/checkInOut/useStatistics");	
				
			}else if("userManager".equals(menu)){
				mav.setViewName("/user/userManager");		
				
			}else if("userReigst".equals(menu)){
				mav.setViewName("/user/userReigst");		
				
			}
		}

		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return mav;
	}
}
